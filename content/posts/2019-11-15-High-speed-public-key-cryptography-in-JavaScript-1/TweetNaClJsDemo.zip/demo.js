const nacl = require('tweetnacl')
nacl.util = require('tweetnacl-util')

const bobKeyPair = nacl.box.keyPair()
const aliceKeyPair = nacl.box.keyPair()
console.log('Bob\'s Key Pair', bobKeyPair)
console.log('Alice\'s Key Pair', aliceKeyPair)

// generating one time nonce for encryption
const nonce = nacl.randomBytes(24)
// Bob encrypts message for Alice
const box = nacl.box(
  nacl.util.decodeUTF8('Hello Alice'),
  nonce,
  aliceKeyPair.publicKey,
  bobKeyPair.secretKey
)
// somehow send this message to Alice
const message = { box, nonce }
console.log('Encrypted message:', message)

// Alice decrypts message from Bob
const payload = nacl.box.open(message.box, message.nonce, bobKeyPair.publicKey, aliceKeyPair.secretKey)
const utf8 = nacl.util.encodeUTF8(payload)
console.log('Decrypted message:', utf8)
