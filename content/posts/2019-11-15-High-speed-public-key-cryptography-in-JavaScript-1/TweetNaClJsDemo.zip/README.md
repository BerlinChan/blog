# TweetNaCl.Js Demo

一个 TweetNaCl.js 的 Demo，详细说明请见文章 [在 Javascript 中实现高速公钥加密(一)](https://www.berlinchan.com/2019/11/High-speed-public-key-cryptography-in-JavaScript-1)

# How to use

    $ npm install
    $ node demo.js
